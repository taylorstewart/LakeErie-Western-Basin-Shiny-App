# USGS Lake Erie Western Basin
A shiny application summarizing trawl catch data in the western basin of Lake Erie from 2013-2014, Spring and Autumn, collected by the U.S. Geological Survey, Great Lakes Science Center, Lake Erie Biological Station.

https://trstewart.shinyapps.io/LEBS_Western_Basin/